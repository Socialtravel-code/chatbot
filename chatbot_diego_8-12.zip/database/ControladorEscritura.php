
<?php
class ControladorEscritura{

        
        public function escribirPHP(){

        }

        public function escribir(){

        }
}