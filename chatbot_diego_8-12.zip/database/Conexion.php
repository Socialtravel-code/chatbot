<?php



class Conexion
{
    private $_conexion = null;
    private $_usuario = 'root';
    private $_clave = 'root';
    public function __construct()
    {
        try {

            $this->_conexion = new PDO("mysql:dbname=masalojamientos;host=localhost", $this->_usuario, $this->_clave, array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES  \'UTF8\''));// string de conexion
            $this->_conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //ANTE ERROR, LANZA UNA EXCEPCION
        } catch (PDOException $e) {
            file_put_contents("log/dberror.log", "Date: " . date('M j Y - G:i:s') . " ---- Error: " . $e->getMessage() . PHP_EOL, FILE_APPEND);
            die($e->getMessage());
        }
    }

    public function getConexion()//expongo la conexion
    {
        return $this->_conexion;
    }

    public function __destruct()// finalizo la conexion
    {
        try {
            $this->_conexion = null; //cierra conexion
        } catch (PDOException $e) {
            file_put_contents("log/dberror.log", "Fecha: " . date('M j Y - G:i:s') . " ---- Error: " . $e->getMessage() . PHP_EOL, FILE_APPEND);
            die($e->getMessage());
        }
    }
}
