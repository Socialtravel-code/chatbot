<?php

include_once 'ControladorPersistencia.php';
include_once 'sqlQuery.php';
include_once 'ControladorMaster.php';
class ControladorBusqueda
{

    protected $refControladorPersistencia;

    function __construct()
    {
        $this->refControladorPersistencia = new ControladorPersistencia();
    }

    public function meta($tabla) //incluyo nombre de tabla para realizar consulta
    {
        $master = new ControladorMaster();
        return $master->metaCompleto($tabla); //envio datos
    }

    public function metaCompleto($tabla)
    {
        $master = new ControladorMaster();
        return $master->metaCompleto($tabla);
    }

    public function buscar($tabla)
    { //busca usando la clase SqlQuery
        $master = new ControladorMaster();
        return $master->buscar($tabla);
    }


    public function eliminar($id, $tabla)
    { //elimina usando SqlQuery clase
        $master = new ControladorMaster();
        $master->eliminar($tabla, $id);
        return ["eliminado" => "eliminado"];
    }


    public function guardar($datosCampos, $tabla)
    { //funcion guardar con SqlQuery implementado
        $master = new ControladorMaster(); //instancio clase array maestro
        $sql = new SqlQuery(); // instancion clase sql
        $arrayMaestro = $sql->meta($tabla); // busco metadata
        array_shift($arrayMaestro); //tablas 
        $datosCampos = compararVista($arrayMaestro, $datosCampos); //comparo los datos que vienen de la vista con los que genero la meta de la BD

        return $master->guardar($tabla, $datosCampos); //llamo a la funcion que realiza el gurdado de los datos

    }



    public function modificar($datosCampos, $tabla)
    { //utiliza clase SqlQuery para automatizar consulta
        $guardar = new SqlQuery(); //instancio objeto de la clase sqlQuery
        $master = new ControladorMaster();
        return $master->modificar($tabla, $datosCampos);
    }
}
