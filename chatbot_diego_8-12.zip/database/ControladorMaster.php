<?php

//require_once 'ControladorGeneral.php';
require_once 'SqlQuery.php';
include_once 'ControladorPersistencia.php';
include_once 'helper/helper.php';

/*
 * Clase generada para servir de controlador maestro 
 */

/**
 * Description of ControladorMaster
 *
 * @author DIEGO
 */
class ControladorMaster
{

    protected  $refControladorPersistencia;
    protected $conn;

    function __construct()
    {
        $this->refControladorPersistencia = new ControladorPersistencia();
        $this->conn = new SqlQuery();
    }

    public function meta($tabla)
    {
        try {
            $objeto = $this->conn->meta($tabla);
            return $objeto;
        } catch (\Throwable $e) {
            echo $e->getTraceAsString();
            $this->refControladorPersistencia->get_conexion()->rollBack(); //si salio mal hace un rollback
        }
    }

    public function metaCompleto($tabla)
    {
        try {
            $objeto = $this->conn->metaCompleto($tabla);
            return $objeto;
        } catch (\Throwable $e) {
            echo $e->getTraceAsString();
            $this->refControladorPersistencia->get_conexion()->rollBack(); //si salio mal hace un rollback
        }
    }

    public function buscar($tabla)
    {
        $buscar = new SqlQuery();
        try {
            $this->refControladorPersistencia->get_conexion()->beginTransaction(); //comienza la transacción
            $statement = $this->refControladorPersistencia->ejecutarSentencia(
                $buscar->buscar($tabla)
            ); //senencia armada desde la clase SqlQuery sirve para comenzar la busqueda
            $array = $statement->fetchAll(PDO::FETCH_ASSOC); //retorna un array asociativo para no duplicar datos
            $this->refControladorPersistencia->get_conexion()->commit(); //si todo salió bien hace el commit            
            return $array; //regreso el array para poder mostrar los datos en la vista... con Ajax... y dataTable de JavaScript
        } catch (PDOException $excepcionPDO) {
            echo "<br>Error PDO: " . $excepcionPDO->getTraceAsString() . '<br>';
            $this->refControladorPersistencia->get_conexion()->rollBack(); //si salio mal hace un rollback
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
            $this->refControladorPersistencia->get_conexion()->rollBack(); //si salio mal hace un rollback
        }
    }

    public function eliminar($tabla, $id)
    {
        $eliminar = new SqlQuery();
        try {
            $this->refControladorPersistencia->get_conexion()->beginTransaction(); //comienzo la transacción
            $this->refControladorPersistencia->ejecutarSentencia(
                $eliminar->eliminar($tabla, $id)
            ); //Uso la funcion correspondiente de controlador pesistencia         
            $this->refControladorPersistencia->get_conexion()->commit(); //ejecuto la acción para eliminar de forma lógica a los ususario
        } catch (PDOException $excepcionPDO) { //excepcion para controlar los errores
            echo "<br>Error PDO: " . $excepcionPDO->getTraceAsString() . '<br>';
            $this->refControladorPersistencia->get_conexion()->rollBack(); //si salio mal hace un rollback
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
            $this->refControladorPersistencia->get_conexion()->rollBack();  //si hay algún error hace rollback
        }
        return ["eliminado" => "eliminado"];
    }

    public function guardar($tabla, $datosCampos)
    {
        $guardar = new SqlQuery();

        try {
            $this->refControladorPersistencia->get_conexion()->beginTransaction();
            //comienza la transacción
            $arrayCabecera = $guardar->meta($tabla); //armo la cabecera del array con los datos de la tabla de BD
            $sentencia = $guardar->armarSentencia($arrayCabecera, $tabla); //armo la sentencia
            $array = $guardar->armarArray($arrayCabecera, $datosCampos); //armo el array con los datos de la vista y los datos que obtuve de la BD
            $this->refControladorPersistencia->ejecutarSentencia($sentencia, $array); //genero la consulta
            $this->refControladorPersistencia->get_conexion()->commit();
        } catch (PDOException $excepcionPDO) {
            echo "<br>Error PDO: " . $excepcionPDO->getTraceAsString() . '<br>';
            $this->refControladorPersistencia->get_conexion()->rollBack(); //si salio mal hace un rollback
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
            $this->refControladorPersistencia->get_conexion()->rollBack();  //si hay algún error hace rollback
        }
        $respuesta = ["status" => "ok"]; //si la transaccion termino correctamente
        return $respuesta; //regreso       

    }

    public function modificar($tabla, $datosCampos)
    {
        $guardar = new SqlQuery();
        $id = $datosCampos["id"];
        try {
            $this->refControladorPersistencia->get_conexion()->beginTransaction();  //comienza la transacción 
            $arrayCabecera = $guardar->meta($tabla); //armo el array con la cabecera de los datos
            $sentencia = $guardar->armarSentenciaModificar($arrayCabecera, $tabla); //genero sentencia
            $array = $guardar->armarArray($arrayCabecera, $datosCampos); //Armo el array con los datos que vienen de la vista y la cabecera de la BD
            array_shift($array); //elimino primer elemento del array que es el id
            array_push($array, $id); //agrego el id al final del array para realizar la consulta
            $this->refControladorPersistencia->ejecutarSentencia($sentencia, $array); //genero la consulta a la BD            
            $this->refControladorPersistencia->get_conexion()->commit();  //si todo salió bien hace el commit            
        } catch (PDOException $excepcionPDO) {
            echo "<br>Error PDO: " . $excepcionPDO->getTraceAsString() . '<br>';
            $this->refControladorPersistencia->get_conexion()->rollBack(); //si salio mal hace un rollback
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
            $this->refControladorPersistencia->get_conexion()->rollBack();  //si hay algún error hace rollback
        }
        $respuesta = ["status" => "ok"]; //si la transaccion termino correctamente
        return $respuesta;
    }

    public function getCampo($datosCampos)
    {
        $i = 0;
        foreach ($datosCampos as $key => $value) {
            if ($i == 1) {
                return $key;
            }
            $i++;
        }
    }
}
