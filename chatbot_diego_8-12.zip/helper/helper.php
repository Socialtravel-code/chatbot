<?php

function compararVista($array, $datos)
{
    $nuevo = array_keys($array);//busco los key en el array
    $nuevo = array_fill_keys($nuevo, NULL);// relleno con NULL
    foreach ($datos as $key => $value) {
        if (array_key_exists($key, $array)) {
            $nuevo[$key] = $datos[$key];//relleno con los datos
        }
    }
    return $nuevo;//regreso el array
}
